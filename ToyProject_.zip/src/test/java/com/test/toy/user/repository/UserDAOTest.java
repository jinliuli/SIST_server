package com.test.toy.user.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class UserDAOTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
